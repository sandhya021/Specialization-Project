import React, { Component, Fragment } from "react";
import { Route, Switch } from "react-router-dom";
import "./App.css";
import Navbar from "./components/Navbar";
import ProductList from "./components/ProductList";
import Details from "./components/Details";
import Cart from "./components/Cart";
import Default from "./components/Default";
import Modal from "./components/Modal";
// import Product from "./components/ProductL";
import Home from "./components/home.js";
import About from "./components/about.js";
import Contact from "./components/contact";
import Poststd from "./components/poststd.js";
import Users from "./components/users";
import Login from "./components/login.js";
import Footer from "./components/footer";
import Payment from "./components/payment";
import Success from "./components/successful";
import SLogin from "./components/sociallogin"

class App extends Component {
  render() {
    return (
      <Fragment>
        <header>
          <Navbar />
        </header>
        <main>
          <Switch>
            <Route exact path="/" component={Home} />
            <Route exact path="/users" component={Users} />
            <Route exact path="/details" component={Details} />
            <Route exact path="/cart" component={Cart} />
            <Route exact path="/about" component={About} />
            <Route exact path="/contact" component={Contact} />
            <Route exact path="/product" component={ProductList} />
            <Route exact path="/register" component={Poststd} />
            <Route exact path="/login" component={Login} />
            <Route exact path="/payment" component={Payment} />
            <Route exact path="/success" component={Success} />
            <Route exact path="/social" component={SLogin} />
           
            <Route component={Default} />
          </Switch>
          <Modal />
        </main>
   
        <div>
        <Footer></Footer>
      </div>
      </Fragment>
  
    )
    
  };
}

export default App;
