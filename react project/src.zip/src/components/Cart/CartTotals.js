import React, { Fragment } from "react";
import PropTypes from "prop-types";
import { Link,Route } from "react-router-dom";
import Payment from "../payment";
import "./cart.css"


const CartTotals = ({
  
  value: { cartTotal, cartTax, cartSubTotal, clearCart }
}) => {
  return (
    <Fragment>
      <div className="contain">
        <div className="row">
          <div className="col-10 mt-2 ml-sm-5 ml-md-auto col-sm-8 text-capitalize text-right">
            {/* <Link to="/"> */}
              <button
                className="btn btn-outline-danger text-uppercase mb-3 px-5"
                onClick={clearCart}>
                clear cart
              </button>
           
            <h5>
              <span className="text-title">subtotal :</span>{" "}
              <strong>
                 {cartSubTotal}
              </strong>{" "}
            </h5>
            <h5>
              <span className="text-title">tax :</span>{" "}
              <strong>
                {cartTax}
              </strong>{" "}
            </h5>
            <h5>
              <span className="text-title">total :</span>{" "}
              <strong>
               Rs.{cartTotal} 
              </strong>{" "}
            </h5>
          </div>
        </div>
        <div className="cart">
        <Link to="/payment" className="checkout-btn">Payment</Link>
        </div>
        <br></br>
      </div>
    </Fragment>
  );
};

// Type checking the properties passed into this component
CartTotals.propTypes = {
  value: PropTypes.shape({
    cartTotal: PropTypes.number.isRequired,
    cartTax: PropTypes.number.isRequired,
    cartSubTotal: PropTypes.number.isRequired,
    clearCart: PropTypes.func.isRequired
  }).isRequired
};

export default CartTotals;
