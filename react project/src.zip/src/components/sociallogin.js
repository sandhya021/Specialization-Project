import React, { Component } from 'react';
import "./login.css";
import { Link } from 'react-router-dom';

import firebase from 'firebase/compat/app';
import 'firebase/compat/auth';
import 'firebase/compat/firestore';
// import firebase from "firebase"
import StyledFirebaseAuth from "react-firebaseui/StyledFirebaseAuth"

firebase.initializeApp({
apiKey: "AIzaSyDLoqcbTDMFuurtAyDgVEKZ6qwo0j0Osjk",
authDomain: "fir-auth-tutorial-ed11f.firebaseapp.com"
})

class SLogin extends Component {

 state = { isSignedIn: false }
uiConfig = {
signInFlow: "popup",
signInOptions: [
firebase.auth.GoogleAuthProvider.PROVIDER_ID,
firebase.auth.FacebookAuthProvider.PROVIDER_ID,
firebase.auth.TwitterAuthProvider.PROVIDER_ID,
firebase.auth.GithubAuthProvider.PROVIDER_ID,
firebase.auth.EmailAuthProvider.PROVIDER_ID
],
callbacks: {
signInSuccess: () => false
}
}

 componentDidMount = () => {
firebase.auth().onAuthStateChanged(user => {
this.setState({ isSignedIn: !!user })
console.log("user", user)
})
}

 render() {
return (
<div className="log">
<br></br>
<img src="https://makegivinghappen.com/wp-content/uploads/2018/06/social-media-banner-3.jpg" class="center" width="500px" alt="..."/>
<br></br>

{this.state.isSignedIn ? (
<span>

<h1 >Welcome {firebase.auth().currentUser.displayName}</h1>

<button><Link to="/">click here to Home page</Link> </button>

<button onClick={() => firebase.auth().signOut()}>Sign out!</button>


</span>
) : (
<StyledFirebaseAuth
uiConfig={this.uiConfig}
firebaseAuth={firebase.auth()}
/>
)}
<br></br>
<br></br>
<br></br>
<br></br>
<br></br>


</div>
)
}

}

export default SLogin;