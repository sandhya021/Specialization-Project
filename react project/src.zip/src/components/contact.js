import React from "react";
import "./contact.css";

const About =() =>{
    return(
        <div>

<h2 >Our Team</h2>
  <div class="row">
    <div class="column">
      <div class="card">
       
        <div class="container">
          <h2>Hanumanth Reddy</h2>
          <p class="title">Member-1</p>
          <p>hanumanth@gmail.com</p>
          <p><button class="button">Contact</button></p>
        </div>
      </div>
    </div>
  
    <div class="column">
      <div class="card">

        <div class="container">
          <h2>Poojitha Unnam</h2>
          <p class="title">Member-2</p>
          <p>poojitha@gmail.com</p>
          <p><button class="button">Contact</button></p>
        </div>
      </div>
    </div>
    
    <div class="column">
      <div class="card">
        
        <div class="container">
          <h2>Roshini Mohankumar</h2>
          <p class="title">Member-3</p>
          <p>roshini@gmail.com</p>
          <p><button class="button">Contact</button></p>
        </div>
      </div>
    </div>


  <div class="column">
    <div class="card">
      
      <div class="container">
        <h2>Sandhya Lokesh</h2>
        <p class="title">Member-4</p>
        <p>sandhya@gmail.com</p>
        <p><button class="button">Contact</button></p>
      </div>
    </div>
  </div>
  </div>
  <br></br>
  <br></br>

  </div> 
    )
 
    
    }
export default About;