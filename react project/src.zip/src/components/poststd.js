import React, { Component } from 'react'
import axios from 'axios'
import "./poststudents.css"
import { Link,Redirect } from "react-router-dom";

class Poststd extends Component{
    constructor(props){
        super(props);
        this.state={
            id:'',
            firstname:'',
            lastname:'',
            emailid:'',
            password:'',
            confirmpassword:'',
            dob:'',
            mobileno:'',
            account:'',
            error:'',
            msg:''

        }
    }
    handleChange=(event)=>
    {

        this.setState({[event.target.name] : event.target.value})
    }

    handleSubmit =(event)=>
    {

        event.preventDefault()
        
        axios.post('http://localhost:8888/saveCustomers',this.state)
        .then(res =>{
            console.log(res.data)
            this.setState(
                {redirect:true}
                )

            
        })
        .catch(error=>{
            console.log(error)
        })
    }

    
    render() {
        const{firstname,lastname,emailid,password,confirmpassword,mobileno}=this.state
        return(
            <div className='b'>
                {this.state.redirect?(<Redirect push to="/login" />):null}
            
                {/* {this.state.redirect?(<Redirect push to="/login" />):null}
            
           <div className='signup'>
                <form onSubmit={this.handleSubmit}>

                <table  align="center" cellpadding = "5">
                <tr>
              <td colspan="2"><h1 >User registration Form</h1></td>
             </tr>
             <hr></hr>

                  
                    
                    <tr>
                       <td htmlFor="firstname">firstname</td>
                        <tr><input type="text" name="firstname" value={firstname} onChange={this.handleChange}/> </tr>
                        </tr>
                       
                      
             <tr>
              <td htmlFor="lastname">lastname</td>
            <tr><input type="text" name="lastname" value={lastname} onChange={this.handleChange}/></tr>
          </tr>
            

                   <tr>
                       <td  htmlFor="emailid">emailid</td>
                        <tr><input type="text" name="emailid" value={emailid} onChange={this.handleChange}/></tr>
                        </tr>
                  

                        <tr>
                    
                       <td  htmlFor="password">password</td>
                        <tr><input type="text" name="password" value={password} onChange={this.handleChange}/></tr>
                   </tr>
             
                        <tr>
                       <td  htmlFor="mobileno">mobileno</td>
                        <tr><input type="text" name="mobileno" value={mobileno} onChange={this.handleChange}/></tr>
                        </tr>
                        
                       
                        <br></br>
                       

                  <tr> 
                       <td><input type="submit" value="register"/></td>
                      <input type="reset" value="clear"/>
                   </tr>
                   
                 </table>
                </form>
                <br></br>
    <br></br>
    <br></br>
    <br></br>
    <br></br>
    <br></br>
                </div>
                <br></br> */}
    <form class="modal-content" action="/login" onSubmit={this.handleSubmit}>
    <div class="container">
      <h1>Sign Up</h1>
      <p>Please fill in this form to create an account.</p>
      <hr/>
      <label for="email"><b>Email</b></label>
      <input type="text" placeholder="Enter Email" name="emailid" value={emailid} onChange={this.handleChange} required/>

      <label for="psw"><b>Password</b></label>
      <input type="password" placeholder="Enter Password" name="password" value={password} onChange={this.handleChange} required/>

      <label for="psw-repeat"><b>Repeat Password</b></label>
      <input type="password" placeholder="Repeat Password" name="confirmpassword" value={confirmpassword} onChange={this.handleChange} required/>
      
      <label>
        <input type="checkbox" checked="checked" name="remember" /> Remember me
      </label>

      <p>By creating an account you agree to our <a href="#" >Terms & Privacy</a>.</p>

      <div class="clearfix">
        <button type="reset" value="clear" class="cancelbtn">Cancel</button>
        <button type="submit" class="signupbtn">Sign Up</button>
      </div>
    </div>
  </form>
                
                </div>
                
            
        )
    }
}
export default Poststd;