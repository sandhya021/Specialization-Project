import React from "react";
import"./s.css";
import { Link,Route } from "react-router-dom";



 const Success =() =>{

    return(    
<div>
<br></br>
<br></br>
<br></br>
<br></br>
<br></br>
<br></br>
<br></br>
<br></br>
<br></br>
<div className="pay">
    <h2>PAYMENT SUCCESSFULL!!!!</h2>
    <br></br>
    <h3>THANK YOU SHOP AGAIN !!!!</h3>
    <br></br>
    <Link to="/product" className="checkout-btn">Go to Product Page</Link>
</div>
<br></br>
<br></br>
<br></br>
<br></br>
<br></br>
<br></br>
<br></br>
<br></br>
<br></br>

</div>
    )
}
export default Success