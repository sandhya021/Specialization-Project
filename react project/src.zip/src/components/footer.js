import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import "./footer.css"
class Footer extends React.Component
{
  render()
  {
    return (
     <footer class="footer"><div class="footer-copyright text-center py-3">© 2022 Copyright:
      <a href="https://mdbootstrap.com/"> mobilestore.com</a><br></br>
      <a href="https://facebook.com/">facebook.com</a><br></br>
       <a href="https://twitter.com/">twitter.com</a></div>


      
      </footer>
    );

    
}
}
export default Footer;


