import React, { useState,useEffect } from 'react';
import "./login.css";
import {useHistory} from "react-router-dom";
import { Link,Route } from "react-router-dom";


export default function Login(){
    const [emailid,setEmail]=useState("");
    const [password,setPassword]=useState("");
    const history=useHistory();
    useEffect(()=>{
        if(localStorage.getItem('user-info')){
            history.push("/login")
        }
    },[])
    async function login()
    {
        console.warn(emailid,password)
        let item={emailid,password};
        let result=await fetch("http://localhost:8888/login",{
            method:'POST',
            headers:{
               "Content-Type":"application/json",
               "Accept":'application/json'
            },
            body:JSON.stringify(item)
        });
        result=await result.json()
        localStorage.setItem("user-info",JSON.stringify(result))
        history.push("/")
    }
   
    return(
            <div className='log'>
               
                  <br></br>
                  <img src="../img/login.png" class="center" width="500px" alt="..."/>
                  <br></br>

                  <div class="btn btn-primar payment"><Link to="/social">Login with Social Accounts click here</Link> </div>
                        <div className='col-sm-4 offset-sm-4'>
                        <input type="text" placeholder='email' required
                        onChange={(e)=>setEmail(e.target.value)}
                         className="form-control"/>
                        <br/>
                        <input type="password" placeholder='password' required
                         onChange={(e)=>setPassword(e.target.value)}
                        className="form-control"/>
                        <br/>

                        <button onClick={login} className="btn btn-primary">Login</button>

     {/* <div class="row">
    <div class="column">
    <Link to="/register" className="checkout-btn">New User Register Here</Link> 
    </div>
    <div class="column">
    <Link to="#"  className="checkout-btn">Forgot Password</Link>
    </div>
  </div> */}
  <div class="bottom-container">
  <div class="row">
    <div class="col">
      <a href="/register" class="btn">Sign up</a>
    </div>
    <div class="col">
      <a href="#"  class="btn">Forgot password?</a>
    </div>
  </div>
</div>
                        
                       
             </div>

             <br></br>
             <br></br>
             <br></br>
             <br></br>
             <br></br>
             <br></br>

         

                        </div>         
               
        );
    
}