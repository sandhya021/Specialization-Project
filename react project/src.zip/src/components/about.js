import React from "react";
import "./about.css";

const About =() =>{
    return(
      <div>
         <br></br>
         <br></br>
        <div>
<div class="about-section">
  <h1>About Mobile Store</h1>
  <p>Technology has transformed the way retail business is done with leading players shifting to mobile specific platforms. The purpose of this study is to examine the mobile shopping adoption using a novel approach of behavioral reasoning theory, which aims to test the relative influence of reasons for, and importance of reasons against adoption of mobile shopping among Indian consumers. The hypotheses were tested using the representative sample of 237 Indian consumers and analyzing the data using PLS-SEM technique. The findings support that ‘reasons for’ and ‘reasons against’ are prime determinant of attitude and intentions. Among the reasons for, price saving orientation is the major determinant for mobile shopping adoption and among the reasons against, self efficacy is the major determinant against mobile shopping adoption. The findings also confirm that value of “openness to change” significantly influences reasons for adoption and has no impact on reasons against and attitude towards mobile shopping. The findings of this study emphasize the importance of examining both the pro-adoption and anti-adoption factors while developing marketing strategy.</p>
  <p>mobile phone use could increase retailer sales, owing toconsumer distraction. That is, because consumers performmultiple tasks (shopping and using mobile devices), theirprocessing abilities diminish, such that these distracted con-sumers spend more time in stores, spend more time in front ofproduct and information displays on shelves, and wander awayfrom a set path more often. For retailers, these behaviors cantranslate into additional sales, especially to consumers whohave diminished abilities to multitask because of their limitedattentional capacity</p>
</div>
  


  </div> 

  <br></br>
  <br></br>
 
  <br></br>
  </div>
    )
 
    
    }
export default About;