import React from "react";

const Home =() =>{
    return<h1> Hello , I am Home page </h1>
};
export default Home;