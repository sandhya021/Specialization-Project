export const MenuItems =[
    {
        title:'Home',
        url: '/home',
        cName: 'nav-links'

    },
    {
        title:'About us',
        url: '/About',
        cName: 'nav-links'
    },
    {
        title:'Products',
        url: '/products',
        cName: 'nav-links'
    },
    {
        title:'Contact us',
        url: '/contact',
        cName: 'nav-links'
    },
    {
        title:'Login',
        url: '/login',
        cName: 'nav-links'
    },
    {
        title:'SignUp',
        url: '/signup',
        cName: 'nav-links'
    },
    {
        title:'Userdetalis',
        url: '/user',
        cName: 'nav-links'
    },
    
]