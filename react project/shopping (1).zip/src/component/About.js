import React from "react";

const About =() =>{
    return<h1> Hello , I am About page </h1>
};
export default About;