import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vehicleloan',
  templateUrl: './vehicleloan.component.html',
  styleUrls: ['./vehicleloan.component.css']
})
export class VehicleloanComponent implements OnInit {

  val:any;
  constructor() { }

  ngOnInit(): void {
  }

  demo(v:any, v1:any){
    this.val=(v*v1*0.07);
    }

}
